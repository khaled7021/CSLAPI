<?php

namespace Drupal\custom_rest_resource\Plugin\rest\resource;

use Drupal\node\Entity\Node;
use Drupal\rest\Plugin\ResourceBase;
use Symfony\Component\HttpFoundation\BinaryFileResponse;
use Symfony\Component\HttpKernel\Exception\NotFoundHttpException;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\DependencyInjection\ContainerInterface;
use Symfony\Component\HttpKernel\Exception\AccessDeniedHttpException;
use Psr\Log\LoggerInterface;
use Drupal\Core\Entity\EntityTypeManagerInterface;

/**
 * Provides a REST API to download a PDF file from a content type.
 *
 * @RestResource(
 *   id = "download_all_pdf",
 *   label = @Translation("Download All Pdf"),
 *   uri_paths = {
 *     "canonical" = "/api/download-module/{type}"
 *   }
 * )
 */

class DownloadAllPdf extends ResourceBase {

  protected $entityTypeManager;

  public function __construct(array $configuration, $plugin_id, $plugin_definition, array $serializer_formats, $logger, EntityTypeManagerInterface $entityTypeManager)
  {
    parent::__construct($configuration, $plugin_id, $plugin_definition, $serializer_formats, $logger);
    $this->entityTypeManager = $entityTypeManager;
  }

  public static function create(ContainerInterface $container, array $configuration, $plugin_id, $plugin_definition)
  {
    return new static(
      $configuration,
      $plugin_id,
      $plugin_definition,
      $container->getParameter('serializer.formats'),
      $container->get('logger.factory')->get('custom_rest_resource_pdf'),
      $container->get('entity_type.manager')
    );
  }

  /**
   * Responds to GET requests.
   *
   * @param string $type
   *   The type value from the URL.
   *
   * @return \Symfony\Component\HttpFoundation\BinaryFileResponse
   *   The file download response.
   */
  public function get($type = NULL) {
    if (!$type) {
      throw new NotFoundHttpException('Type parameter is missing.');
    }

    // Load nodes of the content type with matching field_type.
    $content_type = 'scp_file';
    $storage = $this->entityTypeManager->getStorage('node');
    
    $nids = $storage->getQuery()
      ->accessCheck(true)
      ->condition('type', $content_type)
      ->condition('field_type', $type)
      ->condition('status', 1)
      ->execute();

    if (empty($nids)) {
      throw new NotFoundHttpException('No matching content found for type: ' . $type);
    }

    $node = $storage->loadMultiple($nids);
    $node = reset($node);
    // Get the file from field_link_file.
    if (!$node->hasField('field_link_file') || $node->get('field_link_file')->isEmpty()) {
      throw new NotFoundHttpException('PDF file not found in node.');
    }

    $file = $node->get('field_link_file')->entity;
    $file_path = $file->getFileUri();

    if (!file_exists($file_path)) {
      throw new NotFoundHttpException('PDF file not found.');
    }

    // Prepare response headers.
    $headers = [
      'Content-Type' => 'application/pdf',
      'Content-Disposition' => 'attachment; filename="' . $type . '.pdf"',
    ];

    return new BinaryFileResponse($file_path, 200, $headers, true);
  }
}