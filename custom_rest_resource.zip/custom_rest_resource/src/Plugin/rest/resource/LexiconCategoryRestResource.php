<?php

namespace Drupal\custom_rest_resource\Plugin\rest\resource;

use Drupal\rest\Plugin\ResourceBase;
use Drupal\rest\ResourceResponse;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\DependencyInjection\ContainerInterface;
use Symfony\Component\HttpKernel\Exception\AccessDeniedHttpException;
use Psr\Log\LoggerInterface;
use Drupal\Core\Session\AccountProxyInterface;
use Drupal\Core\Entity\EntityTypeManagerInterface;
use Drupal\Core\Cache\CacheableMetadata;
use Drupal\Core\Cache\Cache;

/**
 * @RestResource(
 *   id = "lexicon_all_category_rest_resource",
 *   label = @Translation("Lexicon All Category Rest Resource"),
 *   uri_paths = {
 *     "canonical" = "/api/lexicon/get-all-categories"
 *   }
 * )
 */
class LexiconCategoryRestResource extends ResourceBase {

  protected $currentUser;
  protected $entityTypeManager;

  public function __construct(
    array $configuration,
    $plugin_id,
    $plugin_definition,
    array $serializer_formats,
    LoggerInterface $logger,
    AccountProxyInterface $current_user,
    EntityTypeManagerInterface $entity_type_manager
  ) {
    parent::__construct($configuration, $plugin_id, $plugin_definition, $serializer_formats, $logger);
    $this->currentUser = $current_user;
    $this->entityTypeManager = $entity_type_manager;
  }

  public static function create(ContainerInterface $container, array $configuration, $plugin_id, $plugin_definition) {
    return new static(
      $configuration,
      $plugin_id,
      $plugin_definition,
      $container->getParameter('serializer.formats'),
      $container->get('logger.factory')->get('lexicon_category'),
      $container->get('current_user'),
      $container->get('entity_type.manager')
    );
  }

  public function get(Request $request) {
    $role_param = $request->query->get('roles');
    $cache_tags = [];

    if (empty($role_param)) {
      $response = new ResourceResponse(['error' => 'Missing roles parameter'], 400);
    }
    else {
      $storage = $this->entityTypeManager->getStorage('node');
      $query = $storage->getQuery()
        ->condition('type', 'lexicon')
        ->condition('status', 1)
        ->condition('field_role', $role_param)
        ->accessCheck(TRUE);
  
      $nids = $query->execute();
      $nodes = $storage->loadMultiple($nids);
  
      $category_ids = [];
      foreach ($nodes as $node) {
        $cache_tags[] = 'node:' . $node->id();
        if ($node->hasField('field_category_reference') && !$node->get('field_category_reference')->isEmpty()) {
          foreach ($node->get('field_category_reference')->referencedEntities() as $category_node) {
            $category_ids[$category_node->id()] = $category_node->getTitle();
            $cache_tags[] = 'node:' . $category_node->id();
          }
        }
        elseif ($node->hasField('field_lexicon_category') && !$node->get('field_lexicon_category')->isEmpty()) {
          foreach ($node->get('field_lexicon_category')->getValue() as $value) {
            $category_titles[] = $value['value'];
          }
          // Merge text values into category_ids with distinct values
          foreach (array_unique($category_titles) as $title) {
            $category_ids[$title] = $title;
          }          
        }
      }
    
    $output = array_values($category_ids);
    $response = new ResourceResponse($output);
    }

    // Apply caching
    $cache_metadata = new CacheableMetadata();
    $cache_metadata->setCacheTags($cache_tags);
    $cache_metadata->setCacheContexts(['url.query_args:roles']);
    $response->addCacheableDependency($cache_metadata);
    
    return $response;
  }
}
