<?php

namespace Drupal\custom_rest_resource\Plugin\rest\resource;

use Drupal\Component\Utility\Html;
use Drupal\Core\Entity\EntityTypeManagerInterface;
use Drupal\Core\Session\AccountProxyInterface;
use Drupal\rest\Plugin\ResourceBase;
use Drupal\rest\ResourceResponse;
use Psr\Log\LoggerInterface;
use Symfony\Component\DependencyInjection\ContainerInterface;
use Symfony\Component\HttpFoundation\Request;

/**
 * @RestResource(
 *   id = "csl_global_search_rest_resource",
 *   label = @Translation("Csl Global Search Rest Resource"),
 *   uri_paths = {
 *     "canonical" = "/api/cms-topics/global-search",
 *     "create" = "/api/cms-topics/global-search"
 *   }
 * )
 */
class CslGlobalSearch extends ResourceBase
{

    protected $currentUser;
    protected $entityTypeManager;

    public function __construct(
        array $configuration,
        $plugin_id,
        $plugin_definition,
        array $serializer_formats,
        LoggerInterface $logger,
        AccountProxyInterface $current_user,
        EntityTypeManagerInterface $entity_type_manager
    ) {
        parent::__construct($configuration, $plugin_id, $plugin_definition, $serializer_formats, $logger);
        $this->currentUser = $current_user;
        $this->entityTypeManager = $entity_type_manager;
    }

    public static function create(ContainerInterface $container, array $configuration, $plugin_id, $plugin_definition)
    {
        return new static(
            $configuration,
            $plugin_id,
            $plugin_definition,
            $container->getParameter('serializer.formats'),
            $container->get('logger.factory')->get('csl_global_search'),
            $container->get('current_user'),
            $container->get('entity_type.manager')
        );
    }

    public function post(Request $request)
    {
        // Decode JSON body
        $searchData = json_decode($request->getContent(), true);
        $search = $searchData['search_key'];
        $limit = 10;
        $offset = (!empty($searchData['offset'])) ? $searchData['offset'] : 0;

        $storage = $this->entityTypeManager->getStorage('node');
        $search = trim($search);
        $search_phrases = [];
        $words = preg_split('/\s+/', $search);

        // Build phrases from longest to shortest
        for ($i = count($words); $i > 0; $i--) {
            $search_phrases[] = implode(' ', array_slice($words, 0, $i));
        }

        // Check if 'field_term' exists for the content type
        $field_definitions = \Drupal::service('entity_field.manager')->getFieldDefinitions('node', 'glossary');
        $field_term_exists = isset($field_definitions['field_term']);

        $query = $storage->getQuery()
            ->accessCheck(true)
            ->condition('status', 1)
            ->sort('title', 'ASC')
            ->sort('field_summary', 'ASC');
        // ->range(0, $limit);

        $results = [];
        foreach ($search_phrases as $phrase) {

            $group = $query->orConditionGroup();
            $group->condition('title', '%' . $phrase . '%', 'LIKE');
            $group->condition('body', '%' . $phrase . '%', 'LIKE');
            $group->condition('field_summary', '%' . $phrase . '%', 'LIKE');
            $group->condition('field_pillar', '%' . $phrase . '%', 'LIKE');
            $group->condition('field_strategic_comm_objective', '%' . $phrase . '%', 'LIKE');
            $group->condition('field_sub_title', '%' . $phrase . '%', 'LIKE');
            $group->condition('field_preferred_terms_phrases', '%' . $phrase . '%', 'LIKE');
            $group->condition('field_non_preferred_terms_phrase', '%' . $phrase . '%', 'LIKE');
            $group->condition('field_alternative_terms_phrase', '%' . $phrase . '%', 'LIKE');
            $group->condition('field_lexicon_category', '%' . $phrase . '%', 'LIKE');
            $group->condition('field_guidance_for_usage', '%' . $phrase . '%', 'LIKE');
            $group->condition('field_citation', '%' . $phrase . '%', 'LIKE');
            $group->condition('field_hcp_narrative', '%' . $phrase . '%', 'LIKE');
            $group->condition('field_lay_narrative', '%' . $phrase . '%', 'LIKE');
            $group->condition('field_definition', '%' . $phrase . '%', 'LIKE');

            // Conditionally add field_term
            if ($field_term_exists) {
                $group->condition('field_term', '%' . $phrase . '%', 'LIKE');
            }

            $query->condition($group);
            $count_query = clone $query;
            $total_count = $count_query->count()->execute();
            $query->range($offset, 10);
            $nids = $query->execute();

            if (!empty($nids)) {
                $nodes = $storage->loadMultiple($nids);
                break; // Stop searching once results are found
            }
        }

        $content_data = [];

        foreach ($nodes as $node) {
            $type = $node->bundle();
            $base_data = [
                'id' => $node->uuid(),
                'type' => $type,
                'title' => $node->label(),
                'role' => [],
                'fileMetaData' => [],
                'imageMetaData' => [],
                'videoMetaData' => [],
            ];

            switch ($type) {
                case 'supporting_evidences':
                    $body = $node->get('body')->value ?? '';
                    $supporting_evidences_title = $node->get('field_summary')->value ?? '';
                    $base_data['body'] = $body;
                    $base_data['supporting_evidences_title'] = $supporting_evidences_title;
                    break;

                case 'scientific_narrative':
                    if ($node->hasField('field_prefix')) {
                        $base_data['pillar'] = $node->get('field_prefix')->value . ' ' . $node->get('field_sequence')->value;
                    }
                    break;

                case 'scientific_platform':
                    if ($node->hasField('field_prefix')) {
                        $base_data['pillar'] = $node->get('field_prefix')->value . ' ' . $node->get('field_sequence')->value;
                    }
                    if ($node->hasField('field_supporting_evidences') && !$node->get('field_supporting_evidences')->isEmpty()) {
                        $referenced_nodes = $node->get('field_supporting_evidences')->referencedEntities();
                        $supporting_items = [];
                        foreach ($referenced_nodes as $ref_node) {
                            $supporting_items[] = '<li>' . Html::escape($ref_node->label()) . '</li>';
                        }
                        $base_data['supporting_evidences_string'] = '<ol>' . implode('', $supporting_items) . '</ol>';
                    }
                    break;

                case 'lexicon':
                    $base_data['preferred_terms'] = $node->get('field_preferred_terms_phrases')->value ?? '';
                    $base_data['alternative_terms'] = $node->get('field_alternative_terms_phrase')->value ?? '';
                    $base_data['guidance_for_usage'] = $node->get('field_guidance_for_usage')->value ?? '';
                    $base_data['category'] = $node->get('field_lexicon_category')->value ?? '';
                    break;

                case 'training_and_guidance':
                    $base_data['category'] = $node->get('field_category')->value ?? '';
                    break;

                case 'disclaimer':
                    $body = $node->get('body')->value ?? '';
                    $base_data['body'] = $body;
                    break;

                case 'glossary':
                    $definition = $node->get('field_definition')->value ?? '';
                    $base_data['definition'] = $definition;
                    break;

                default:
                    $base_data = [
                        'id' => $node->uuid(),
                        'type' => $type,
                        'title' => $node->label(),
                        'role' => [],
                        'fileMetaData' => [],
                        'imageMetaData' => [],
                        'videoMetaData' => [],
                    ];
                    break;
            }

            $content_data[] = $base_data;
        }
        // printf('data1',$content_data);
        $hasMore = "false";
        if ($total_count > $offset) {
            $hasMore = "true";
        }

        $response = [
            'hasMore' => $hasMore,
            'limit' => $limit,
            'content' => $content_data,
        ];

        return new ResourceResponse($response);
    }
}
