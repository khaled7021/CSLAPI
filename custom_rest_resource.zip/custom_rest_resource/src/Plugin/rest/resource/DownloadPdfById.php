<?php

namespace Drupal\custom_rest_resource\Plugin\rest\resource;

use Drupal\Core\Entity\EntityTypeManagerInterface;
use Drupal\rest\Plugin\ResourceBase;
use Symfony\Component\DependencyInjection\ContainerInterface;
use Symfony\Component\HttpFoundation\BinaryFileResponse;
use Symfony\Component\HttpKernel\Exception\NotFoundHttpException;

/**
 * Provides a REST API to download a PDF file.
 *
 * @RestResource(
 *   id = "download_pdf_by_id",
 *   label = @Translation("Download Pdf By Id"),
 *   uri_paths = {
 *     "canonical" = "/api/download-reference/{id}"
 *   }
 * )
 */
class DownloadPdfById extends ResourceBase
{

    protected $entityTypeManager;

    public function __construct(array $configuration, $plugin_id, $plugin_definition, array $serializer_formats, $logger, EntityTypeManagerInterface $entityTypeManager)
    {
        parent::__construct($configuration, $plugin_id, $plugin_definition, $serializer_formats, $logger);
        $this->entityTypeManager = $entityTypeManager;
    }

    public static function create(ContainerInterface $container, array $configuration, $plugin_id, $plugin_definition)
    {
        return new static(
            $configuration,
            $plugin_id,
            $plugin_definition,
            $container->getParameter('serializer.formats'),
            $container->get('logger.factory')->get('custom_rest_resource'),
            $container->get('entity_type.manager')
        );
    }

    /**
     * Responds to GET requests.
     *
     * @param string $type
     *   The type value from the URL.
     *
     * @return \Symfony\Component\HttpFoundation\BinaryFileResponse
     *   The file download response.
     */
    public function get($id = null)
    {
        if (!$id) {
            throw new NotFoundHttpException('id is missing.');
        }

        //  Load the file entity by UUID
        $file_storage = \Drupal::entityTypeManager()->getStorage('file');
        $files = $file_storage->loadByProperties(['uuid' => $id]);

        if (!empty($files)) {
            $file = reset($files);
            $file_path = $file->getFileUri();
            $file_name = $file->getFilename();
        } else {
            throw new NotFoundHttpException('No matching content found for id: ' . $id);
        }

        if (!file_exists($file_path)) {
            throw new NotFoundHttpException('PDF file not found.');
        }

        // Prepare response headers.
        $headers = [
            'Content-Type' => 'application/pdf',
            'Content-Disposition' => 'attachment; filename="' . $file_name . '"',
        ];

        return new BinaryFileResponse($file_path, 200, $headers, true);
    }
}
