<?php

namespace Drupal\custom_rest_resource\Plugin\rest\resource;

use Drupal\rest\Plugin\ResourceBase;
use Drupal\rest\ResourceResponse;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\DependencyInjection\ContainerInterface;
use Symfony\Component\HttpKernel\Exception\AccessDeniedHttpException;
use Psr\Log\LoggerInterface;
use Drupal\Core\Session\AccountProxyInterface;
use Drupal\Core\Entity\EntityTypeManagerInterface;
use Drupal\Core\Cache\CacheableMetadata;
use Drupal\Core\Cache\Cache;
use Drupal\Component\Utility\Html;

/**
 * @RestResource(
 *   id = "csl_global_search_rest_resource_demo",
 *   label = @Translation("Csl Global Search Rest Resource Demo"),
 *   uri_paths = {
 *     "canonical" = "/api/cms-topics/global-searchdemo",
 *     "create" = "/api/cms-topics/global-searchdemo"
 *   }
 * )
 */
class CslGlobalSearchDemo extends ResourceBase {

  protected $currentUser;
  protected $entityTypeManager;

  public function __construct(
    array $configuration,
    $plugin_id,
    $plugin_definition,
    array $serializer_formats,
    LoggerInterface $logger,
    AccountProxyInterface $current_user,
    EntityTypeManagerInterface $entity_type_manager
  ) {
    parent::__construct($configuration, $plugin_id, $plugin_definition, $serializer_formats, $logger);
    $this->currentUser = $current_user;
    $this->entityTypeManager = $entity_type_manager;
  }

  public static function create(ContainerInterface $container, array $configuration, $plugin_id, $plugin_definition) {
    return new static(
      $configuration,
      $plugin_id,
      $plugin_definition,
      $container->getParameter('serializer.formats'),
      $container->get('logger.factory')->get('csl_global_search'),
      $container->get('current_user'),
      $container->get('entity_type.manager')
    );
  }

  public function post(Request $request) {
    // Decode JSON body
    $searchData = json_decode($request->getContent(), true);     
    $search = $searchData['search'];
    $type = $searchData['type'];
    $limit = 10;
        
    $storage = $this->entityTypeManager->getStorage('node');
    $search = trim($search);
    $search_phrases = [];
    $words = preg_split('/\s+/', $search);
    
    // Build phrases from longest to shortest
    for ($i = count($words); $i > 0; $i--) {
      $search_phrases[] = implode(' ', array_slice($words, 0, $i));
    }

    $query = $storage->getQuery()
      ->accessCheck(TRUE)
      ->condition('status', 1)
      ->sort('title', 'ASC');
      // ->range(0, $limit);

    // Filter by content types if provided
    if (!empty($searchData['type']) && is_array($searchData['type'])) {
      $query->condition('type', $searchData['type'], 'IN');
    }
    
    $nids = $query->execute();

    if (!empty($nids)) {
      $nodes = $storage->loadMultiple($nids);
    
      $fields_to_check = [
        'title',
        'body',
        'field_summary',
        'field_prefix',
        'field_strategic_comm_objective',
        'field_sub_title',
        'field_preferred_terms_phrases',
        'field_non_preferred_terms_phrase',
        'field_alternative_terms_phrase',
        'field_lexicon_category',
        'field_guidance_for_usage',
        'field_citation',
        'field_hcp_narrative',
        'field_lay_narrative',
        'field_definition',
        'field_term',
      ];
    
      foreach ($search_phrases as $phrase) {
        foreach ($nodes as $node) {
          foreach ($fields_to_check as $field_name) {
            $value = '';
            if ($node->hasField($field_name) && !$node->get($field_name)->isEmpty()) {

              // Special case: merge field_prefix and field_sequence
              if ($field_name === 'field_prefix' && !$node->get('field_prefix')->isEmpty()) {
                $prefix = $node->get('field_prefix')->value ?? '';
                $sequence = $node->get('field_sequence')->value ?? '';
                $pillar = trim($prefix . ' ' . $sequence);
      
                if (!empty($pillar) && str_contains(strtolower($pillar), strtolower($phrase))) {
                  $results[] = $node;
                  break 3; 
                }
              }  
              else {
                $value = $node->get($field_name)->value;
              }
            }
    
            if (!empty($value) && str_contains(strtolower($value), strtolower($phrase))) {
              $results[] = $node;
              break 3; // Stop checking other fields once matched
            }
          }
        }
      }
    }

    $content_data = [];
  
    foreach ($results as $node) {
      $type = $node->bundle();
      $base_data = [
        'id' => $node->uuid(),
        'type' => $type,
        'title' => $node->label(),
        'role' => [],
        'fileMetaData' => [],
        'imageMetaData' => [],
        'videoMetaData' => [],
      ];
  
      switch ($type) {
        case 'supporting_evidences':
          $body = $node->get('body')->value ?? '';
          $supporting_evidences_title = $node->get('field_summary')->value ?? '';
          $base_data['body'] = $body;
          $base_data['supporting_evidences_title'] = $supporting_evidences_title;
          break;

        case 'scientific_narrative':
          if ($node->hasField('field_prefix')) {
            $base_data['pillar'] = $node->get('field_prefix')->value . ' ' . $node->get('field_sequence')->value;
          }
          break;
  
        case 'scientific_platform':
          if ($node->hasField('field_prefix')) {
            $base_data['pillar'] = $node->get('field_prefix')->value . ' ' . $node->get('field_sequence')->value;
          }
          if ($node->hasField('field_supporting_evidences') && !$node->get('field_supporting_evidences')->isEmpty()) {
            $referenced_nodes = $node->get('field_supporting_evidences')->referencedEntities();
            $supporting_items = [];
            foreach ($referenced_nodes as $ref_node) {
              $supporting_items[] = '<li>' . Html::escape($ref_node->label()) . '</li>';
            }
            $base_data['supporting_evidences_string'] = '<ol>' . implode('', $supporting_items) . '</ol>';
          }
          break;
  
        case 'lexicon':
          $base_data['preferred_terms'] = $node->get('field_preferred_terms_phrases')->value ?? '';
          $base_data['alternative_terms'] = $node->get('field_alternative_terms_phrase')->value ?? '';
          $base_data['guidance_for_usage'] = $node->get('field_guidance_for_usage')->value ?? '';
          $base_data['category'] = $node->get('field_lexicon_category')->value ?? '';
          break;
  
        case 'training_and_guidance':
          $base_data['category'] = $node->get('field_category')->value ?? '';
          break;
        
        case 'disclaimer':
          $body = $node->get('body')->value ?? '';
          $base_data['body'] = $body;
          break;

        case 'glossary':
          $definition = $node->get('field_definition')->value ?? '';
          $base_data['definition'] = $definition;
          break;
  
        default:   
          $base_data = [
            'id' => $node->uuid(),
            'type' => $type,
            'title' => $node->label(),
            'role' => [],
            'fileMetaData' => [],
            'imageMetaData' => [],
            'videoMetaData' => [],
          ];
          break;
      }
  
      $content_data[] = $base_data;
    }
    // printf('data1',$content_data);
    $response = [
      'hasMore' => count($content_data) === $limit,
      'limit' => $limit,
      'content' => $content_data,
    ];

    return new ResourceResponse($response);
  }
}