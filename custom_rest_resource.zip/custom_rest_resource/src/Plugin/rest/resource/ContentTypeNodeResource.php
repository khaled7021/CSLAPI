<?php

namespace Drupal\custom_rest_resource\Plugin\rest\resource;

use Drupal\Core\Cache\CacheableMetadata;
use Drupal\Core\Entity\EntityTypeManagerInterface;
use Drupal\node\Entity\Node;
use Drupal\rest\Plugin\ResourceBase;
use Drupal\rest\ResourceResponse;
use Symfony\Component\DependencyInjection\ContainerInterface;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpKernel\Exception\BadRequestHttpException;

/**
 * Provides a REST API for content type nodes.
 *
 * @RestResource(
 *   id = "content_type_node_resource",
 *   label = @Translation("Content Type Node Resource"),
 *   uri_paths = {
 *     "canonical" = "/api/cms-topics",
 *     "create" = "/api/cms-topics"
 *   }
 * )
 */

class ContentTypeNodeResource extends ResourceBase
{

    protected $entityTypeManager;

    public function __construct(array $configuration, $plugin_id, $plugin_definition, array $serializer_formats, $logger, EntityTypeManagerInterface $entityTypeManager)
    {
        parent::__construct($configuration, $plugin_id, $plugin_definition, $serializer_formats, $logger);
        $this->entityTypeManager = $entityTypeManager;
    }

    public static function create(ContainerInterface $container, array $configuration, $plugin_id, $plugin_definition)
    {
        return new static(
            $configuration,
            $plugin_id,
            $plugin_definition,
            $container->getParameter('serializer.formats'),
            $container->get('logger.factory')->get('custom_rest_resource'),
            $container->get('entity_type.manager')
        );
    }

    public function post(Request $request)
    {

        // Decode JSON body
        $getContent = json_decode($request->getContent(), true);

        // Validate content type
        if (empty($getContent['type'])) {
            throw new BadRequestHttpException('Missing contenttype parameter in request body.');
        }

        $content_type = $getContent['type'];
        //$this->logger->info('Body Fetching content type: ' . $content_type);

        $lexicon_category = (!empty($getContent['lexicon_category'])) ? $getContent['lexicon_category'] : "";
        //$this->logger->info('Body Fetching lexicon_category: ' . '<pre>' . print_r($lexicon_category, true) . '</pre>');

        $role = (!empty($getContent['roles'])) ? $getContent['roles'] : "";
        //$this->logger->info('Body Fetching content type: ' . '<pre>' . print_r($role, true) . '</pre>');

        $offset = (!empty($getContent['next'])) ? $getContent['next'] : 0;

        $filters = (!empty($getContent['filters'])) ? $getContent['filters'] : "";

        if (empty($content_type)) {
            throw new BadRequestHttpException('Missing contenttype parameter.');
        }

        $storage = \Drupal::entityTypeManager()->getStorage('node');

        // Build the base query with all conditions
        $query = $storage->getQuery()
            ->accessCheck(true)
            ->condition('status', 1);

        // Apply conditions based on content type
        if ($content_type === 'lexicon') {
            // Create AND condition group
            $group = $query->andConditionGroup();
            $group->condition('type', $content_type);

            if (!empty($lexicon_category)) {
                $group->condition('field_lexicon_category', $lexicon_category, 'IN');
            }
            if (!empty($role)) {
                $group->condition('field_role', $role[0]);
            }

            $query->condition($group);
            $query->sort('field_lexicon_category', 'ASC');
            $query->sort('title', 'ASC');
        } else if ($content_type === 'reference_list') {
            $group = $query->andConditionGroup();
            $group->condition('type', $content_type);
            if (!empty($filters)) {
                $filterTitle = $filters[0]['filterValue'];
                $this->logger->info('filterTitle: ' . '<pre>' . print_r($filterTitle, true) . '</pre>');
                $group->condition('title', '%' . $filterTitle . '%', 'LIKE');
            }
            $query->condition($group);
            //$query->sort('field_lexicon_category', 'ASC');

        } else {
            // Create OR condition group
            $group = $query->orConditionGroup();
            $group->condition('type', $content_type);
            $query->condition($group);
            $query->sort('field_sequence', 'ASC')
                ->sort('title', 'ASC');
        }

        /* if (!empty($filters)) {
        $filterTitle = $filters[0]['filterValue'];
        $this->logger->info('filterTitle: ' . '<pre>' . print_r($filterTitle, true) . '</pre>');
        $group->condition('title', '%' . $filterTitle . '%', 'LIKE');
        }*/

        // Clone the query for counting
        $count_query = clone $query;
        $total_count = $count_query->count()->execute();

        $next = "";
        $this->logger->info('Count: ' . print_r($total_count, true));

        // Apply sorting and range for actual node loading
        $query->range($offset, 10);

        $nids = $query->execute();
        $nodes = $storage->loadMultiple($nids);

        $data = [];
        $content_data = [];
        $supporing_evidences_data = [];
        $prefix_value = "";
        $sequence = "";
        $title = "";
        $term = "";
        $preferred_terms_phrases = "";
        $guidance_for_usage = "";
        $non_preferred_terms = "";
        $alternative_terms = "";
        $category = "";
        $definition = "";
        $citation = "";
        $key_scientific_statement = "";
        $role = [];
        $viva_version = "";
        $viva_published_date = "";
        $body = "";
        $file_data = "";
        $hcp_narrative = "";
        $lay_narrative = "";

        $this->logger->info('Total Nodes: ' . print_r($total_count, true));
        foreach ($nodes as $node) {
            //$this->logger->info('Node values: ' . print_r($node, true));
            $title = $node->label();

            if ($node->hasField('field_prefix')) {
                $prefix_value = $node->get('field_prefix')->value;
                $sequence = $node->get('field_sequence')->value;
                // Use $prefix_value as needed
            }
            if ($node->hasField('field_supporting_evidences') && !$node->get('field_supporting_evidences')->isEmpty()) {
                $referenced_nodes = $node->get('field_supporting_evidences')->referencedEntities();

                foreach ($referenced_nodes as $ref_node) {
                    $ref_title = $ref_node->label();
                    $ref_body = $ref_node->get('body')->value;
                    $supporing_evidences_data[] = [
                        'supporting_evidences_title' => $ref_title,
                        'body' => $ref_body,
                    ];

                    // You can log or use these values as needed
                    // $this->logger->info("Referenced Node - Title: $ref_title, Body: $ref_body");
                }
            }

            if ($node->hasField('field_preferred_terms_phrases')) {
                $preferred_terms_phrases = $node->get('field_preferred_terms_phrases')->value;
            }
            if ($node->hasField('field_guidance_for_usage')) {
                $guidance_for_usage = $node->get('field_guidance_for_usage')->value;
            }
            if ($node->hasField('field_lexicon_category')) {
                $category = $node->get('field_lexicon_category')->value;
            }
            if ($node->hasField('field_non_preferred_terms_phrase')) {
                $non_preferred_terms = $node->get('field_non_preferred_terms_phrase')->value;
            }
            if ($node->hasField('field_alternative_terms_phrase')) {
                $alternative_terms = $node->get('field_alternative_terms_phrase')->value;
            }
            if ($node->hasField('field_definition')) {
                $definition = $node->get('field_definition')->value;
            }

            if ($node->hasField('field_role')) {
                $role = $node->get('field_role')->value;
            }

            if ($node->hasField('field_term')) {
                $term = $node->get('field_term')->value;
            } else {
                $term = $title;
            }

            if ($node->hasField('field_citation')) {
                $citation = $node->get('field_citation')->value;
            }
            if ($node->hasField('field_link_file') && !$node->get('field_link_file')->isEmpty()) {
                $file = $node->get('field_link_file')->entity;
                //$this->logger->info('file values: ' . print_r($file, true));
                if ($file) {
                    $file_uuid = $file->uuid();
                    $file_name = $file->getFilename();
                    $file_size = $file->getSize();
                    $file_data = [
                        'type' => 'application/pdf',
                        'fileId' => $file_uuid,
                        'fileName' => $file_name,
                        'fileSize' => $file_size,
                    ];
                }
            }

            if ($node->hasField('field_strategic_comm_objective')) {
                $strategic_comm_objective = $node->get('field_strategic_comm_objective')->value;
                $sub_title = $node->get('field_sub_title')->value;
                $key_scientific_statement = $sub_title . ":" . $strategic_comm_objective;
            }

            if ($content_type == "scp_version") {
                $viva_version = $node->get('field_version')->value;
                $viva_published_date = \Drupal::service('date.formatter')->format($node->get('field_published_date')->value, 'custom', 'Y-m-d H:i:s');
            }

            if ($content_type == "disclaimer") {
                $body = $node->get('body')->value;
            }

            if ($node->hasField('field_hcp_narrative')) {
                $hcp_narrative = $node->get('field_hcp_narrative')->value;
            }

            if ($node->hasField('field_lay_narrative')) {
                $lay_narrative = $node->get('field_lay_narrative')->value;
            }

            $created_date = \Drupal::service('date.formatter')->format($node->getCreatedTime(), 'custom', 'Y-m-d H:i:s');
            $updated_date = \Drupal::service('date.formatter')->format($node->getChangedTime(), 'custom', 'Y-m-d H:i:s');
            // Created by
            $creator_uid = $node->getOwnerId();
            $creator = \Drupal\user\Entity\User::load($creator_uid);
            $creator_name = $creator->getDisplayName();

            // Updated by (last revision user)
            $updater_uid = $node->getRevisionUserId();
            $updater = \Drupal\user\Entity\User::load($updater_uid);
            $updater_name = $updater->getDisplayName();

            $content_data[] = [
                'id' => $node->uuid(),
                'type' => $node->bundle(),
                'version' => $node->getRevisionId(),
                'title' => $title,
                'citation' => $citation,
                'term' => $term,
                'definition' => $definition,
                'role' => [$role],
                'preferred_terms' => $preferred_terms_phrases,
                'non_preferred_terms' => $non_preferred_terms,
                'alternative_terms' => $alternative_terms,
                'guidance_for_usage' => $guidance_for_usage,
                'pillar' => $prefix_value . ' ' . $sequence,
                'supporting_evidences' => $supporing_evidences_data,
                'body' => $body,
                'hcp_narrative' => $hcp_narrative,
                'lay_narrative' => $lay_narrative,
                'key_scientific_statement' => $key_scientific_statement,
                'category' => $category,
                'fileMetaData' => [$file_data],
                'imageMetaData' => [],
                'videoMetaData' => [],
                'viva_version' => $viva_version,
                'viva_published_date' => $viva_published_date,
                'createdAt' => $created_date,
                'updatedAt' => $updated_date,
                'createdBy' => $creator_name,
                'updatedBy' => $updater_name,
            ];
        }

        if ($total_count - intval($next) > 10) {
            $next = $offset + 10;
        } else {
            $next = "";
        }
        $data = [
            'next' => $next,
            'limit' => 10,
            'content' => $content_data,
        ];

        //return new ResourceResponse($data);

        $response = new ResourceResponse($data);
        $cache_metadata = new CacheableMetadata();
        $cache_metadata->addCacheContexts(['url', 'user']);
        $cache_metadata->addCacheTags(['node_list', 'node:' . $content_type]);
        $cache_metadata->setCacheMaxAge(3600); // Cache for 1 hour
        $response->addCacheableDependency($cache_metadata);
        return $response;

    }
}
