<?php

namespace Drupal\custom_rest_resource\Plugin\rest\resource;

use Drupal\Core\Cache\CacheableMetadata;
use Drupal\node\Entity\Node;
use Drupal\rest\Plugin\ResourceBase;
use Drupal\rest\ResourceResponse;
use Symfony\Component\DependencyInjection\ContainerInterface;
use Symfony\Component\HttpKernel\Exception\NotFoundHttpException;
use Drupal\custom_rest_resource\Services\HtmlReferenceTransformer;

/**
 * Provides a REST Resource to fetch node details by type and ID.
 *
 * @RestResource(
 *   id = "content_type_detail_resource",
 *   label = @Translation("Content Type Detail Resource"),
 *   uri_paths = {
 *     "canonical" = "/api/cms-topics/{type}/{id}",
 *     "create" = "/api/cms-topics/{type}/{id}"
 *   }
 * )
 */
class ContentTypeDetailResource extends ResourceBase
{

    protected $htmlReferenceTransformer;

    public static function create(ContainerInterface $container, array $configuration, $plugin_id, $plugin_definition)
    {
        return new static(
            $configuration,
            $plugin_id,
            $plugin_definition,
            $container->getParameter('serializer.formats'),
            $container->get('logger.factory')->get('custom_rest_resource'),
            $container->get('custom_rest_resource.html_reference_transformer')
        );
    }

    public function __construct(array $configuration, $plugin_id, $plugin_definition, array $serializer_formats, $logger, HtmlReferenceTransformer $htmlReferenceTransformer)
    {
        parent::__construct($configuration, $plugin_id, $plugin_definition, $serializer_formats, $logger);
        $this->htmlReferenceTransformer = $htmlReferenceTransformer;
    }

    public function get($type = null, $id = null)
    {
        if (!$type || !$id) {
            throw new NotFoundHttpException('Missing type or id.');
        }

        $entity_type_manager = \Drupal::entityTypeManager();
        $storage = $entity_type_manager->getStorage('node');
        $ids = $storage->getQuery()
            ->accessCheck(true)
            ->condition('uuid', $id)
            ->execute();

        if (!empty($ids)) {
            $nid = reset($ids);
            // Now you have the node ID
        }

        $node = Node::load($nid);
        if (!$node || $node->bundle() !== $type) {
            throw new NotFoundHttpException('Node not found or type mismatch.');
        }

        
        if ($node->hasField('field_prefix')) {
            $prefix_value = $node->get('field_prefix')->value;
            $sequence = $node->get('field_sequence')->value;
            // Use $prefix_value as needed
        }

        if ($node->hasField('field_supporting_evidences') && !$node->get('field_supporting_evidences')->isEmpty()) {
            $referenced_nodes = $node->get('field_supporting_evidences')->referencedEntities();

            foreach ($referenced_nodes as $ref_node) {
                $ref_title = $ref_node->label();
                $ref_body = $ref_node->get('body')->value;
                $transformed_body = $this->htmlReferenceTransformer->updateBodyAndSaveUrl($ref_body);
                
                $supporing_evidences_data[] = [
                    'supporting_evidences_title' => $ref_title,
                    'body' => $transformed_body,
                ];
               
            }
        }

        $data[] = [
            'id' => $node->uuid(),
            'type' => $node->bundle(),
            'version' => $node->getRevisionId(),
            'title' => $node->label(),
            'role' => [],
            'pillar' => $prefix_value . " " . $sequence,
            'supporting_evidences' => $supporing_evidences_data,
            'fileMetaData' => [],
            'imageMetaData' => [],
            'videoMetaData' => [],
            'createdAt' => \Drupal::service('date.formatter')->format($node->getCreatedTime(), 'custom', 'Y-m-d H:i:s'),
            'updatedAt' => \Drupal::service('date.formatter')->format($node->getChangedTime(), 'custom', 'Y-m-d H:i:s'),
            'createdBy' => $node->getOwner()->getDisplayName(),
            'updatedBy' => \Drupal\user\Entity\User::load($node->getRevisionUserId())->getDisplayName(),
        ];

        $response = new ResourceResponse($data);
        $cache_metadata = new CacheableMetadata();
        $cache_metadata->addCacheTags(['node:' . $node->id()]);
        $cache_metadata->addCacheContexts(['url']);
        $response->addCacheableDependency($cache_metadata);

        return $response;
    }
}
