<?php

namespace Drupal\custom_rest_resource\Plugin\rest\resource;

use Drupal\Core\Cache\CacheableMetadata;
use Drupal\Core\Entity\EntityTypeManagerInterface;
use Drupal\node\Entity\Node;
use Drupal\rest\Plugin\ResourceBase;
use Drupal\rest\ResourceResponse;
use Symfony\Component\DependencyInjection\ContainerInterface;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpKernel\Exception\BadRequestHttpException;

/**
 * Provides a REST API for content type nodes.
 *
 * @RestResource(
 *   id = "lexicon_category_filter_result",
 *   label = @Translation("Lexicon Category Filter Result"),
 *   uri_paths = {
 *     "canonical" = "/api/cms-topics/search",
 *     "create" = "/api/cms-topics/search"
 *   }
 * )
 */

class LexiconCategoryFilterResult extends ResourceBase
{

    protected $entityTypeManager;

    public function __construct(array $configuration, $plugin_id, $plugin_definition, array $serializer_formats, $logger, EntityTypeManagerInterface $entityTypeManager)
    {
        parent::__construct($configuration, $plugin_id, $plugin_definition, $serializer_formats, $logger);
        $this->entityTypeManager = $entityTypeManager;
    }

    public static function create(ContainerInterface $container, array $configuration, $plugin_id, $plugin_definition)
    {
        return new static(
            $configuration,
            $plugin_id,
            $plugin_definition,
            $container->getParameter('serializer.formats'),
            $container->get('logger.factory')->get('custom_rest_resource'),
            $container->get('entity_type.manager')
        );
    }

    public function post(Request $request)
    {

        // Decode JSON body
        $getContent = json_decode($request->getContent(), true);

        // Validate content type
        if (empty($getContent['type'])) {
            throw new BadRequestHttpException('Missing contenttype parameter in request body.');
        }

        $content_type = $getContent['type'];
        //$this->logger->info('Body Fetching content type: ' . $content_type);

        $lexicon_category = (!empty($getContent['lexicon_category'])) ? $getContent['lexicon_category'] : "";
        //$this->logger->info('Body Fetching lexicon_category: ' . '<pre>' . print_r($lexicon_category, true) . '</pre>');

        $role = (!empty($getContent['roles'])) ? $getContent['roles'] : "";
        //$this->logger->info('Body Fetching content type: ' . '<pre>' . print_r($role, true) . '</pre>');
        
        $offset = isset($getContent['offset']) ? (int) $getContent['offset'] : 0;
        $limit = isset($getContent['limit']) ? (int) $getContent['limit'] : 10;

        if (empty($content_type)) {
            throw new BadRequestHttpException('Missing contenttype parameter.');
        }

        $storage = \Drupal::entityTypeManager()->getStorage('node');

        // Build the base query with all conditions
        $query = $storage->getQuery()
            ->accessCheck(true)
            ->condition('status', 1);

        // Create and condition group
        $group = $query->andConditionGroup();
        $group->condition('type', $content_type);

        if (!empty($lexicon_category)) {
            $group->condition('field_lexicon_category', $lexicon_category);
        }

        if (!empty($role)) {
            $group->condition('field_role', $role[0]);
        }

        $query->condition($group);

        $next = "";
        // Apply sorting and range for actual node loading
        $query->sort('field_sequence', 'ASC')
            ->sort('title', 'ASC');
            // ->range($offset, 10);

        $nids = $query->execute();
        $nodes = $storage->loadMultiple($nids);

        $data = [];
        $content_data = [];
        $supporing_evidences_data = [];
        $title = "";
        $preferred_terms_phrases = "";
        $guidance_for_usage = "";
        $non_preferred_terms = "";
        $category = "";
        $role = [];
        
        foreach ($nodes as $node) {
            //$this->logger->info('Node values: ' . print_r($node, true));
            $title = $node->label();

            if ($node->hasField('field_supporting_evidences') && !$node->get('field_supporting_evidences')->isEmpty()) {
                $referenced_nodes = $node->get('field_supporting_evidences')->referencedEntities();

                foreach ($referenced_nodes as $ref_node) {
                    $ref_title = $ref_node->label();
                    $ref_body = $ref_node->get('body')->value;
                    $supporing_evidences_data[] = [
                        'supporting_evidences_title' => $ref_title,
                        'body' => $ref_body,
                    ];
                }
            }

            if ($node->hasField('field_preferred_terms_phrases')) {
                $preferred_terms_phrases = $node->get('field_preferred_terms_phrases')->value;
            }
            if ($node->hasField('field_guidance_for_usage')) {
                $guidance_for_usage = $node->get('field_guidance_for_usage')->value;
            }
            if ($node->hasField('field_lexicon_category')) {
                $category = $node->get('field_lexicon_category')->value;
            }
            if ($node->hasField('field_non_preferred_terms_phrase')) {
                $non_preferred_terms = $node->get('field_non_preferred_terms_phrase')->value;
            }
            if ($node->hasField('field_role')) {
                $role = $node->get('field_role')->value;
            }
            
            $created_date = \Drupal::service('date.formatter')->format($node->getCreatedTime(), 'custom', 'Y-m-d H:i:s');
            $updated_date = \Drupal::service('date.formatter')->format($node->getChangedTime(), 'custom', 'Y-m-d H:i:s');
            // Created by
            $creator_uid = $node->getOwnerId();
            $creator = \Drupal\user\Entity\User::load($creator_uid);
            $creator_name = $creator->getDisplayName();

            // Updated by (last revision user)
            $updater_uid = $node->getRevisionUserId();
            $updater = \Drupal\user\Entity\User::load($updater_uid);
            $updater_name = $updater->getDisplayName();

            $content_data[] = [
                'id' => $node->uuid(),
                'type' => $node->bundle(),
                'version' => $node->getRevisionId(),
                'title' => $title,
                'role' => [$role],
                'preferred_terms' => $preferred_terms_phrases,
                'non_preferred_terms' => $non_preferred_terms,
                'guidance_for_usage' => $guidance_for_usage,
                'supporting_evidences' => $supporing_evidences_data,
                'category' => $category,
                'fileMetaData' => [],
                'imageMetaData' => [],
                'videoMetaData' => [],
                'createdAt' => $created_date,
                'updatedAt' => $updated_date,
                'createdBy' => $creator_name,
                'updatedBy' => $updater_name,
            ];
        }
        
        $data = [
            'next' => $next,
            'limit' => 10,
            'content' => $content_data,
        ];

        //return new ResourceResponse($data);

        $response = new ResourceResponse($data);
        $cache_metadata = new CacheableMetadata();
        $cache_metadata->addCacheContexts(['url', 'user']);
        $cache_metadata->addCacheTags(['node_list', 'node:' . $content_type]);
        $cache_metadata->setCacheMaxAge(3600); // Cache for 1 hour
        $response->addCacheableDependency($cache_metadata);
        return $response;

    }
}
