<?php

namespace Drupal\custom_rest_resource\Services;


use Drupal\Core\Url;
use Drupal\file\Entity\File;
use Drupal\Core\StreamWrapper\StreamWrapperManagerInterface;
use Drupal\Component\Serialization\Json;

// use Symfony\Component\DomCrawler\Crawler;

class HtmlReferenceTransformer {

  public function updateBodyAndSaveUrl($body) {
    $result = $body;
    $regex = '/<a [^>]*>.*?<\/a>/s';
    $matches = [];

    if (preg_match_all($regex, $body, $matches) && !empty($matches)) {
      foreach ($matches as $index => $content) {
        foreach ($content as $key => $value) {

          $txt_content = $value ?? null;
          $replacement = $this->generateReplacement($txt_content, $key);
          $result = preg_replace('/' . preg_quote($txt_content, '/') . '/', $replacement, $result, 1);
        }
      }
      return $result;
    }
  }

  public function generateReplacement($content, $index) {
    
    $href_with_url = explode('href="', $content, 2); // limit=2 keeps it efficient
    $reference_after_href = $href_with_url[1] ?? null;  
    
    if ($reference_after_href !== '') {
      // Split on the next " and take element 0 which is the URL value
      $url = explode('"', $reference_after_href, 2)[0];
  
      // Split on the next " and take element 1 which is the Reference File name
      $anchor_file_name = explode('"', $reference_after_href, 2)[1];
      // Extract clean file reference name
      $file_reference_name = $this->custom_rest_resource_remove_sub_and_sup_script($anchor_file_name);
    
      // strip query string if needed
      $url_no_query = explode('?', $url, 2)[0];

      if ($url_no_query !== '') {
        // Safely get the last path segment and URL-decode it (e.g., "FDA%20news.pdf" -> "FDA news.pdf").
        $path = parse_url($url_no_query, PHP_URL_PATH) ?? '';
        // Gets the file name from the path. Removes any trailing slashes from the path and get basename.
        $lastSegment = $path !== '' ? basename(rtrim($path, '/')) : '';
        $fileName = $lastSegment !== '' ? rawurldecode($lastSegment) : '';
        $current_file_url = $this->custom_rest_resource_attach_current_domain($url_no_query);
        $current_file_uri = $this->custom_rest_resource_uri_from_absolute_url($current_file_url);
        $file_id = $this->custom_rest_resource_fid_by_uri($current_file_uri);

        $fileEntity = [
          'id' => (string) $file_id,
          'name' => $file_reference_name !== '' ? $file_reference_name : $fileName, 
          'index' => $index,
        ];
        
        $referenceString = Json::encode($fileEntity);
        
        return "CSL_REFERENCES_METADATA: [$referenceString]";
      }
    }

    return $replacement;
  }

  
  public function custom_rest_resource_uri_from_absolute_url(string $url) {
    $path = parse_url($url, PHP_URL_PATH) ?? '';
  
    if (preg_match('@/system/files/(.*)$@i', $path, $m)) {
      // URL-encoded characters (like %20 for spaces) are properly decoded.
      return 'private://' . rawurldecode($m[1]);
    }
  
    /** @var StreamWrapperManagerInterface $swm */
    $swm = \Drupal::service('stream_wrapper_manager');
    $public = $swm->getViaScheme('public'); // \Drupal\Core\StreamWrapper\PublicStream
    if ($public) {
      // e.g. "sites/default/files"
      $publicDir = '/' . trim($public->getDirectoryPath(), '/');
      if (preg_match('@^' . preg_quote($publicDir, '@') . '/(.*)$@', $path, $m)) {
        return 'public://' . rawurldecode($m[1]);
      }
    }
  
    return null;
  }
  
      
  public function custom_rest_resource_attach_current_domain(string $absoluteUrl): string {
    
    // Get the current request details.
    $request    = \Drupal::request(); 
    $schemeHost = $request->getSchemeAndHttpHost(); 
    $baseUrl    = $request->getBaseUrl();   
    
    // Pull path from the incoming URL.
    $path = parse_url($absoluteUrl, PHP_URL_PATH) ?? '/';

    // Rebuild the URL on the current host.
    return $schemeHost . $baseUrl . $path;
  }  

  
  public function custom_rest_resource_fid_by_uri($uri): ?string {
    $files = \Drupal::entityTypeManager()
      ->getStorage('file')
      ->loadByProperties(['uri' => $uri]);
  
    if (!empty($files)) {
      /** @var \Drupal\file\FileInterface $file */
      $file = reset($files);
      return (string) $file->uuid();
    }
    return null;
  }

  public function custom_rest_resource_remove_sub_and_sup_script($input): ?string {
    if ($input === null) {
      return null;
    }
    
    $decoded = html_entity_decode($input);
    // Remove sub and sup tags
    $cleaned = str_replace(['<sup>', '</sup>','<sub>', '</sub>', '</a>', '>'], '', $decoded);

    return $cleaned;
  }
}